# Source Map and Reading Coverage

## Snapshot and scope

- Source: [The Level Design Book](https://book.leveldesignbook.com/).
- Reading snapshot: **2026-10-16**.
- Discovery: [llms.txt](https://book.leveldesignbook.com/llms.txt), checked against [sitemap-pages.xml](https://book.leveldesignbook.com/sitemap-pages.xml).
- **94 unique indexed pages retrieved and read.** The sitemap and documentation index matched after normalizing the home page and Markdown suffixes.
- Reading scope: the page bodies, tables, figure captions/alt text, examples, and in-page technical listings. Image/video embeds were not a substitute for watching the media or playing the games; figures were not exhaustively visually inspected.
- External linked articles, talks, books, source repositories, asset libraries, and games are **not** counted as independently read, watched, audited, or played.
- Temporary source caches are not included in this skill. This directory contains new wording, condensed analysis, task routing, checklists, and templates rather than the source corpus.

## How to interpret coverage

Every row was visited; **read** does not mean **complete source**. “Body” means substantive text, not a claim that the page is final. The entire book is under construction, and some substantive pages also contain TODOs.

“Draft,” “short,” “outline,” and “STUB” describe the snapshot, not a judgment of importance. Where this skill extends a draft into practical checks, it identifies those checks as adaptations rather than attributing missing material to the original author.

The book's authorial interpretations and forecasts are kept separate from established facts and measured results. Numerical examples, tool versions, platform opinions, prices, and community descriptions require current verification when relevant.

## Page-level ledger

| ID | Source page | Source state | Skill reference | Use or limitation |
| --- | --- | --- | --- | --- |
| 00 | [The Level Design Book](https://book.leveldesignbook.com/) | Overview | [foundations](foundations.md) | Purpose, audience, construction status. |
| 01 | [What is level design](https://book.leveldesignbook.com/introduction) | Body | [foundations](foundations.md) | Definition, scope, and boundaries of the discipline. |
| 02 | [How to make a level](https://book.leveldesignbook.com/process/overview) | Body | [foundations](foundations.md) | Iterative production; avoid a rigid pipeline. |
| 03 | [Pre-production](https://book.leveldesignbook.com/process/preproduction) | Body | [foundations](foundations.md) | Goals, pillars, references, and planning. |
| 04 | [Pacing](https://book.leveldesignbook.com/process/preproduction/pacing) | Body | [foundations](foundations.md) | Beats, structure, intensity, and counterarguments. |
| 05 | [Research](https://book.leveldesignbook.com/process/preproduction/research) | Body | [foundations](foundations.md) | Real-world and game reference; analytical breakdowns. |
| 06 | [Worldbuilding](https://book.leveldesignbook.com/process/preproduction/worldbuilding) | Body | [foundations](foundations.md) | Minimal/comprehensive worldbuilding and supporting documents. |
| 07 | [Scope](https://book.leveldesignbook.com/process/preproduction/scope) | Body | [foundations](foundations.md) | Production scope and vertical slices. |
| 08 | [Combat](https://book.leveldesignbook.com/process/combat) | Body | [combat-balance](combat-balance.md) | Combat systems versus local spatial arrangements. |
| 09 | [Enemy design](https://book.leveldesignbook.com/process/combat/enemy) | Body | [combat-balance](combat-balance.md) | Legible enemy roles and behavior relationships. |
| 10 | [Encounter](https://book.leveldesignbook.com/process/combat/encounter) | Body | [combat-balance](combat-balance.md) | Encounter construction, variation, and difficulty. |
| 11 | [Cover](https://book.leveldesignbook.com/process/combat/cover) | Body | [combat-balance](combat-balance.md) | Sightlines, protection, movement, and tradeoffs. |
| 12 | [Map balance](https://book.leveldesignbook.com/process/combat/balance) | Body | [combat-balance](combat-balance.md) | Competitive relationships, control, timing, and resources. |
| 13 | [Layout](https://book.leveldesignbook.com/process/layout) | Body | [spatial-layout](spatial-layout.md) | Communicating and revising spatial organization. |
| 14 | [Flow](https://book.leveldesignbook.com/process/layout/flow) | Body | [spatial-layout](spatial-layout.md) | Movement and activity over time. |
| 15 | [Circulation](https://book.leveldesignbook.com/process/layout/flow/circulation) | Body | [spatial-layout](spatial-layout.md) | Routes, connections, and circulation. |
| 16 | [Verticality](https://book.leveldesignbook.com/process/layout/flow/verticality) | Body | [spatial-layout](spatial-layout.md) | Height as a functional relationship. |
| 17 | [Critical path](https://book.leveldesignbook.com/process/layout/criticalpath) | Body | [spatial-layout](spatial-layout.md) | Required progression versus optional exploration. |
| 18 | [Parti](https://book.leveldesignbook.com/process/layout/parti) | Short notes | [spatial-layout](spatial-layout.md) | Organizing diagram; not an elaborate documented method. |
| 19 | [Typology](https://book.leveldesignbook.com/process/layout/typology) | Body / partial | [spatial-layout](spatial-layout.md) | Recognizable spatial types and adaptation. |
| 20 | [Gates](https://book.leveldesignbook.com/process/layout/typology/gates) | Short body | [spatial-layout](spatial-layout.md) | Hard/soft gates, keys, and shortcuts. |
| 21 | [Blockout](https://book.leveldesignbook.com/process/blockout) | Body | [blockout-metrics](blockout-metrics.md) | Cheap playable spatial hypotheses. |
| 22 | [Massing](https://book.leveldesignbook.com/process/blockout/massing) | Body | [blockout-metrics](blockout-metrics.md) | Large forms, empty space, and spatial hierarchy. |
| 23 | [Landscape](https://book.leveldesignbook.com/process/blockout/massing/landscape) | Body | [blockout-metrics](blockout-metrics.md) | Landforms, landscape architecture, and playable terrain. |
| 24 | [Composition](https://book.leveldesignbook.com/process/blockout/massing/composition) | Body | [blockout-metrics](blockout-metrics.md) | Moving views; limits of screenshot-based composition. |
| 25 | [Prospect-refuge](https://book.leveldesignbook.com/process/blockout/massing/prospect-refuge) | Body | [blockout-metrics](blockout-metrics.md) | Surveying, shelter, and limits of the theory. |
| 26 | [Metrics](https://book.leveldesignbook.com/process/blockout/metrics) | Body | [blockout-metrics](blockout-metrics.md) | Measured dimensions and gameplay quantities. |
| 27 | [Modular kit design](https://book.leveldesignbook.com/process/blockout/metrics/modular) | Partial draft | [blockout-metrics](blockout-metrics.md) | Kit scale, grid, connections, and pilot testing. |
| 28 | [Doom metrics](https://book.leveldesignbook.com/process/blockout/metrics/doom) | Game-specific tables | [blockout-metrics](blockout-metrics.md) | Doom dimensions and gameplay data; verify version. |
| 29 | [Quake metrics](https://book.leveldesignbook.com/process/blockout/metrics/quake) | Game-specific tables | [blockout-metrics](blockout-metrics.md) | Quake dimensions and gameplay data; verify version. |
| 30 | [Wayfinding](https://book.leveldesignbook.com/process/blockout/wayfinding) | Body | [wayfinding-playtesting](wayfinding-playtesting.md) | Player interpretation and layered guidance. |
| 31 | [Playtesting](https://book.leveldesignbook.com/process/blockout/playtesting) | Body | [wayfinding-playtesting](wayfinding-playtesting.md) | Planning, observing, interpreting, and revising. |
| 32 | [Player persona](https://book.leveldesignbook.com/process/blockout/playtesting/persona) | Short draft | [wayfinding-playtesting](wayfinding-playtesting.md) | Provisional audience model; not a complete persona method. |
| 33 | [Scripting](https://book.leveldesignbook.com/process/scripting) | Body | [scripting-doors](scripting-doors.md) | Events, conditions, actions, and local behavior. |
| 34 | [(stub) Navigation](https://book.leveldesignbook.com/process/scripting/nav) | STUB | [scripting-doors](scripting-doors.md) | No complete navigation chapter; checks are labeled extensions. |
| 35 | [Doors](https://book.leveldesignbook.com/process/scripting/doors) | Body | [scripting-doors](scripting-doors.md) | Interactions, actors, state, and production dependencies. |
| 36 | [Lighting](https://book.leveldesignbook.com/process/lighting) | Body | [lighting-art](lighting-art.md) | Functional illumination, depth, atmosphere, and information. |
| 37 | [Three point lighting](https://book.leveldesignbook.com/process/lighting/three-point) | Short body | [lighting-art](lighting-art.md) | Key/fill/back-light study; not a complete level solution. |
| 38 | [D6 lighting](https://book.leveldesignbook.com/process/lighting/d6-lighting) | Partial draft | [lighting-art](lighting-art.md) | First three strategies explained; later entries are headings. |
| 39 | [Lighting for darkness](https://book.leveldesignbook.com/process/lighting/darkness) | Body | [lighting-art](lighting-art.md) | Readable darkness and intentional alternatives. |
| 40 | [Environment Art](https://book.leveldesignbook.com/process/env-art) | Body | [lighting-art](lighting-art.md) | Art passes that preserve and retest functionality. |
| 41 | [Shape and color psychology](https://book.leveldesignbook.com/process/env-art/psychology) | Body | [lighting-art](lighting-art.md) | Critique of universal shape/color psychology. |
| 42 | [Texturing](https://book.leveldesignbook.com/process/env-art/texturing) | Body | [lighting-art](lighting-art.md) | Surface scale, materials, detail, and readability. |
| 43 | [Storytelling](https://book.leveldesignbook.com/process/env-art/storytelling) | Short body | [lighting-art](lighting-art.md) | Environmental evidence, choreography, and plot dependencies. |
| 44 | [Optimization](https://book.leveldesignbook.com/process/env-art/optimization) | Body | [optimization-release](optimization-release.md) | Memory, CPU/GPU costs, profiling, and contextual budgets. |
| 45 | [Release](https://book.leveldesignbook.com/process/release) | Body | [optimization-release](optimization-release.md) | Packaging, documentation, portfolios, and release reflection. |
| 46 | [Level design as culture](https://book.leveldesignbook.com/culture/overview) | Overview | [culture-history](culture-history.md) | Culture, history, research, and criticism. |
| 47 | [History of the level designer](https://book.leveldesignbook.com/culture/history-level-designer) | Critical essay | [culture-history](culture-history.md) | Professional role, editors, modding, specialization, futures. |
| 48 | [Zero player level design](https://book.leveldesignbook.com/culture/zero-player) | Critical essay | [culture-history](culture-history.md) | Automatic levels, spectatorship, and local genres. |
| 49 | [(unfinished pages)](https://book.leveldesignbook.com/culture/unfinished-pages) | Index of drafts | [culture-history](culture-history.md) | Preserve the unfinished status of the listed material. |
| 50 | [History of architecture](https://book.leveldesignbook.com/culture/unfinished-pages/history-of-architecture) | Partial draft | [culture-history](culture-history.md) | Incomplete architectural timeline; research pointers only. |
| 51 | [Structural engineering primer](https://book.leveldesignbook.com/culture/unfinished-pages/structural-engineering-primer) | STUB | [culture-history](culture-history.md) | Placeholder, not a structural-engineering reference. |
| 52 | [History of environment art](https://book.leveldesignbook.com/culture/unfinished-pages/history-of-environment-art) | Short draft | [culture-history](culture-history.md) | Incomplete notes, not a completed art-history survey. |
| 53 | [History of furniture](https://book.leveldesignbook.com/culture/unfinished-pages/history-of-furniture) | Partial draft | [culture-history](culture-history.md) | Period, manufacture, use, and incomplete chronology. |
| 54 | [History of encounter design](https://book.leveldesignbook.com/culture/unfinished-pages/history-encounter-design) | Substantial draft | [culture-history](culture-history.md) | Placement, authored AI, dynamic systems, and retro reactions. |
| 55 | [How to study a level](https://book.leveldesignbook.com/studies/overview) | Method note | [case-studies](case-studies.md) | Close reading and evidence limits. |
| 56 | [Single player studies](https://book.leveldesignbook.com/studies/sp) | Index | [case-studies](case-studies.md) | Single-player case-study navigation. |
| 57 | [Undead Burg (Dark Souls 1)](https://book.leveldesignbook.com/studies/sp/undead-burg) | Substantial WIP | [case-studies](case-studies.md) | Exploration patterns, routes, encounters, returns, and shortcuts. |
| 58 | [Assassins (Thief 1)](https://book.leveldesignbook.com/studies/sp/assassins) | Body | [case-studies](case-studies.md) | Stealth, changed spatial meaning, and private/public power. |
| 59 | [(STUB) The Cradle (Thief 3)](https://book.leveldesignbook.com/studies/sp/cradle) | STUB | [case-studies](case-studies.md) | Title only; no completed Cradle analysis. |
| 60 | [(STUB) Sapienza (Hitman)](https://book.leveldesignbook.com/studies/sp/sapienza) | STUB | [case-studies](case-studies.md) | Title only; no completed Sapienza analysis. |
| 61 | [(STUB) Silent Cartographer (Halo 1)](https://book.leveldesignbook.com/studies/sp/silent-cartographer) | STUB | [case-studies](case-studies.md) | Title only; no completed Silent Cartographer analysis. |
| 62 | [Multiplayer studies](https://book.leveldesignbook.com/studies/mp) | Index | [case-studies](case-studies.md) | Multiplayer case-study navigation. |
| 63 | [Chill Out (Halo 1)](https://book.leveldesignbook.com/studies/mp/chill-out) | Body | [case-studies](case-studies.md) | Halo rules, asymmetric circulation, resources, and control. |
| 64 | [(STUB) de_dust2 (Counter-Strike)](https://book.leveldesignbook.com/studies/mp/de_dust2) | STUB | [case-studies](case-studies.md) | Title only; no completed de_dust2 analysis. |
| 65 | [Real world studies](https://book.leveldesignbook.com/studies/irl) | Index | [case-studies](case-studies.md) | Real-world case-study navigation. |
| 66 | [Disneyland (California, USA)](https://book.leveldesignbook.com/studies/irl/disneyland) | Body | [case-studies](case-studies.md) | Landmarks, boundaries, rides, and critical interpretation. |
| 67 | [(STUB) Las Vegas (Nevada, USA)](https://book.leveldesignbook.com/studies/irl/stub-las-vegas-nevada-usa) | STUB | [case-studies](case-studies.md) | Reminder to discuss Learning from Las Vegas. |
| 68 | [Notes for educators](https://book.leveldesignbook.com/learning/notes) | Body | [learning](learning.md) | Tools, curriculum, critique, pin-ups, and pedagogy. |
| 69 | [Project plans](https://book.leveldesignbook.com/learning/projects) | Index / brief notes | [learning](learning.md) | Project selection and complete iteration cycles. |
| 70 | [Classic Combat](https://book.leveldesignbook.com/learning/projects/classic-combat) | Developed project | [learning](learning.md) | Small classic-combat arena: research through reflection. |
| 71 | [(Unfinished WIP pages)](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages) | Index of drafts | [learning](learning.md) | Other projects explicitly remain WIP. |
| 72 | [Modern Combat](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/modern-combat) | Incomplete project | [learning](learning.md) | Modern encounter research, sketch, pitch; tooling unresolved. |
| 73 | [Modern Stealth](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/modern-stealth) | Incomplete project | [learning](learning.md) | Stealth observation and AI research; not a full build plan. |
| 74 | [Exercise: Direct Lighting](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/exercise-direct-lighting) | Short exercise | [learning](learning.md) | Direct/fill lighting as a learning constraint. |
| 75 | [Exercise: Whiteboard 2D](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/exercise-whiteboard-2d) | Exercise outline | [learning](learning.md) | 2D layout, collectibles, and screen visibility. |
| 76 | [Level Design Portfolio](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/level-design-portfolio) | Draft outline | [learning](learning.md) | Portfolio presentation; platform opinions are time-sensitive. |
| 77 | [Design Test: Adaptation](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/adaptation) | Short brief | [learning](learning.md) | Adapt a real place through typology, massing, and scope. |
| 78 | [Exercise: Layout](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/exercise-floorplan) | Exercise outline | [learning](learning.md) | Unlock-and-leave layout comparisons. |
| 79 | [Exercise: Verticality](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/verticality) | Short exercise | [learning](learning.md) | Major heights, transitions, landings, and communication. |
| 80 | [Tools](https://book.leveldesignbook.com/appendix/tools) | Resource directory | [tools-quake](tools-quake.md) | Engines, editors, art tools, and planning tools. |
| 81 | [TrenchBroom](https://book.leveldesignbook.com/appendix/tools/trenchbroom) | Tool overview | [tools-quake](tools-quake.md) | Brush workflow, integrations, assets, and entity limits. |
| 82 | [Assets & Resources](https://book.leveldesignbook.com/appendix/resources) | Resource directory | [tools-quake](tools-quake.md) | Models, textures, blockout materials, skies, and 2D assets. |
| 83 | [Recommended talks](https://book.leveldesignbook.com/appendix/resources/talks) | Bibliography | [tools-quake](tools-quake.md) | Talk categories and links; talks not independently consumed. |
| 84 | [Recommended books](https://book.leveldesignbook.com/appendix/resources/books) | Bibliography | [tools-quake](tools-quake.md) | Generalist, industry, reference, and architecture books. |
| 85 | [Quake resources](https://book.leveldesignbook.com/appendix/resources/quake) | Resource guide | [tools-quake](tools-quake.md) | Compilers, source ports, assets, mods, modeling, QuakeC. |
| 86 | [How to package a Quake map/mod](https://book.leveldesignbook.com/appendix/resources/quake/how-to-package) | Technical guide | [tools-quake](tools-quake.md) | Simple map, full mod, and partial add-on packaging. |
| 87 | [File formats](https://book.leveldesignbook.com/appendix/resources/formats) | Index | [tools-quake](tools-quake.md) | File-format navigation. |
| 88 | [FGD file format](https://book.leveldesignbook.com/appendix/resources/formats/fgd) | Technical guide | [tools-quake](tools-quake.md) | Editor entity definitions and their runtime limits. |
| 89 | [MAP file format](https://book.leveldesignbook.com/appendix/resources/formats/map) | Technical guide | [tools-quake](tools-quake.md) | Text geometry/entities, planes, and format variants. |
| 90 | [MDL file format](https://book.leveldesignbook.com/appendix/resources/formats/mdl) | Third-party archive | [tools-quake](tools-quake.md) | David Henry article: GFDL; code has separate notices. |
| 91 | [Communities](https://book.leveldesignbook.com/appendix/communities) | Resource directory | [tools-quake](tools-quake.md) | Game-specific help, visual critique, and criticism venues. |
| 92 | [About this book / authors](https://book.leveldesignbook.com/appendix/about) | Attribution | [License](../LICENSE.md) | Authors, contributors, and project context. |
| 93 | [License / copyright](https://book.leveldesignbook.com/appendix/license) | Rights notice | [License](../LICENSE.md) | CC BY-NC-SA and separately attributed material. |

## Adaptation boundaries

- **Entry point:** SKILL.md contains task routing and a minimal evidence-driven operating loop.
- **Twelve topical references:** consolidate related pages while preserving important disagreements, genre assumptions, and source gaps.
- **Three templates:** newly organized brief, playtest report, and review structures. They are not original forms from the book.
- **No hidden source expansion:** a title-only case study does not become a completed analysis; an external bibliography entry does not become inherited evidence.
- **No bundled third-party assets or archival code:** especially the separately licensed MDL material.
- **Rights and attribution:** see [LICENSE.md](../LICENSE.md). Adapted explanatory material is CC BY-NC-SA 4.0.

## Refresh procedure

1. Retrieve the index and sitemap again.
2. Compare additions, removals, renamed URLs, and substantive page changes.
3. Read changed pages, including their rights notices and newly completed sections.
4. Update relevant topical references, source-state labels, and the snapshot.
5. Verify internal links, source coverage, frontmatter, and task routing.
6. Keep adaptations distinguishable from source claims and actual test evidence.
